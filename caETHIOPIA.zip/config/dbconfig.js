
  module.exports = {
    HOST: "localhost",
    USER: "abi",
    PASSWORD: "password",
    DB: "caimportexport",
  };



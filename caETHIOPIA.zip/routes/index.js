const express = require('express');
const router = express.Router();

const connection = require('../database/dbconnection');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const { v4: uuidv4 } = require('uuid');
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');
router.get('/', forwardAuthenticated, (req, res) => res.render('login'));
router.get('/login', forwardAuthenticated, (req, res) => res.render('login'));
router.get('/forgetpassword', forwardAuthenticated, (req, res) => res.render('forgetpassword',{user:req.user}));
router.get('/dashboard', ensureAuthenticated, (req, res) => res.render('dashboard',{user:req.user}));
router.get('/addaccount', ensureAuthenticated, (req, res) => res.render('addaccount',{user:req.user}));
router.get('/addcustomer', ensureAuthenticated, (req, res) => res.render('addcustomer',{user:req.user}));
router.get('/addinventory', ensureAuthenticated, (req, res) => res.render('addinventory',{user:req.user}));
router.get('/addsales', ensureAuthenticated, (req, res) => res.render('addsales',{user:req.user}));
router.get('/adduser', ensureAuthenticated, (req, res) => res.render('adduser',{user:req.user}));
router.get('/inventorytransaction', ensureAuthenticated, (req, res) => res.render('inventorytransaction',{user:req.user}));
router.get('/salestransaction', ensureAuthenticated, (req, res) => res.render('salestransaction',{user:req.user}));
router.get('/data', ensureAuthenticated, (req, res) => res.render('data',{user:req.user}));
router.get('/addpayment', ensureAuthenticated, (req, res) => res.render('addpayment',{user:req.user}));
router.get('/addnewproduct', ensureAuthenticated, (req, res) => res.render('addnewproduct',{user:req.user}));

router.post('/addforgetpassword', forwardAuthenticated, async function(req, res) {res.render('forgetpassword',{user:req.user})});
router.post('/addnewaccount', ensureAuthenticated, async function(req, res) 

{
  const{bankname,accountnumber,intialbalance} = req.body;

  let errors = [];
  if(!bankname || !accountnumber || !intialbalance)
  {
   errors.push("PLease Enter Required Fields!")
  }
  if(errors.length > 0)
  {
    res.render('addaccount',{user:req.user,errors,error_msg:'Please All The Required Fields!'})
  }
  else{
    const v1options = {
      node: [0x01, 0x23],
      clockseq: 0x1234,
      msecs: new Date('2011-11-01').getTime(),
      nsecs: 5678,
    };
    accountid = uuidv4(v1options);
    var sql_query = "Insert into account (accountid,bankname,accountnumber,intialbalance) values (?,?,?,?)";
    connection.query(sql_query,[accountid,bankname,accountnumber,parseFloat(intialbalance)],function(error,results,fields)
    {
      if(error)
      {
        console.log(error);
        res.render('addaccount',{user:req.user,
          error_msg:'Connection Error PLease Try Later!'
          });
      }
      else
      {
        res.render('addaccount',{user:req.user,
        success_msg:'You Are Successfully Add New Bank Account!'
        });
      }
    })
  
  }


});
router.post('/addnewcustomer', ensureAuthenticated, async function(req, res){ 
  const{customername,customeraddress,customerphone,intialbalance} = req.body;

  let errors = [];
  if(!customerphone || !customeraddress || !intialbalance || !customername)
  {
 errors.push('Please All The Required Fields!');
  }
  if(errors.length > 0)
  {
    res.render('addcustomer',{user:req.user,errors,error_msg:'Please All The Required Fields!'})
  }
  else{
    const v1options = {
      node: [0x01, 0x23],
      clockseq: 0x1234,
      msecs: new Date('2011-11-01').getTime(),
      nsecs: 5678,
    };
    customerid = uuidv4(v1options);
    var sql_query = "Insert into customer (customerid,customername,customeraddress,customerphone,intialbalance) values (?,?,?,?,?)";
    connection.query(sql_query,[customerid,customername,customeraddress,customerphone,parseFloat(intialbalance)],function(error,results,fields)
    {
      if(error)
      {
        console.log(error);
        res.render('addaccount',{user:req.user,
          error_msg:'Connection Error PLease Try Later!'
          });
      }
      else
      {
        res.render('addaccount',{user:req.user,
        success_msg:'You Are Successfully Add New Customer Info!'
        });
      }
    })
  
  }


});
router.post('/addnewinventory', ensureAuthenticated, async function(req, res) { 
  const{inventorymanager,inventoryaddress,contactphone,inventoryname} = req.body;

  let errors = [];
  if(!inventorymanager || ! inventoryaddress || ! contactphone || !inventoryname)
  {
  errors.push('Please All The Required Fields!');
  }
  if(errors.length > 0)
  {
    res.render('addinventory',{user:req.user,errors,error_msg:'Please All The Required Fields!'})
  }
  else{
    const v1options = {
      node: [0x01, 0x23],
      clockseq: 0x1234,
      msecs: new Date('2011-11-01').getTime(),
      nsecs: 5678,
    };
    inventoryid = uuidv4(v1options);
    var sql_query = "insert into inventory (inventoryid,inventorymanager,inventoryaddress,contactphone,inventoryname) values (?,?,?,?,?)";
    connection.query(sql_query,[inventoryid,inventorymanager,inventoryaddress,contactphone,inventoryname],function(error,results,fields)
    {
      if(error)
      {
        res.render('addinventory',{user:req.user,
          error_mgs:'Connection Error PLease Try Later!'
          });
      }
      else
      {
        res.render('addinventory',{user:req.user,
        success_mgs:'You Are Successfully Add New Inventory Info!'
        });
      }
    })
  
  }



});
router.post('/addsales', ensureAuthenticated, async function(req, res) {res.render('addsales',{user:req.user})});
router.post('/adduser', ensureAuthenticated, async function(req, res)  {
  const{bankname,accountnumber,intialbalance} = req.body;

  let errors = [];
  if(!bankname || !accountnumber || !intialbalance)
  {

  }
  if(errors.length > 0)
  {
    res.render('adduser',{user:req.user,errors,error_msg:'Please All The Required Fields!'})
  }
  else{
    var sql_query = "";
    connection.query(sql_query,function(error,results,fields)
    {
      if(error)
      {
        res.render('adduser',{user:req.user,
          error_mgs:'Connection Error PLease Try Later!'
          });
      }
      else
      {
        res.render('adduser',{user:req.user,
        success_mgs:'You Are Successfully Add New System User!'
        });
      }
    })
  
  }


});
router.post('/loadinventorytransaction', ensureAuthenticated, async function(req, res)  {res.render('inventorytransaction',{user:req.user})});
router.post('/laodsalestransaction', ensureAuthenticated, async function(req, res) {res.render('salestransaction',{user:req.user})});
router.post('/laoddata', ensureAuthenticated, async function(req, res)  {res.render('data',{user:req.user})});
router.post('/addpayment', ensureAuthenticated, async function(req, res) {res.render('addpayment',{user:req.user})});
router.post('/addnewproduct', ensureAuthenticated, async function(req, res)  {res.render('addnewproduct',{user:req.user})});

















router.post('/login', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
  })(req, res, next);
});


router.get('/logout', (req, res) => {
  req.logout();
  req.flash('success_msg', 'You are logged out');
  res.redirect('/login');
});


module.exports = router;